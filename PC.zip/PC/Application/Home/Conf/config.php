<?php
return array(
	//'配置项'=>'配置值'
	'TMPL_L_DELIM'=>'<{',
	'TMPL_R_DELIM'=>'}>',
	'DB_TYPE'=>'mysql',
	'DB_HOST'=>'localhost',
	'DB_NAME'=>'pc',
	'DB_USER'=>'root',
	'DB_PWD'=>'123123',
	'DB_PORT'=>'3306',
	'DB_PREFIX'=>'',		//设置表前缀
);
